var CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
var BASE_URL = document.querySelector("meta[name='base_url']").getAttribute("content");


$(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: { url: BASE_URL + "/admin/index", },
        order: [[0, 'desc']],
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'name', name: 'name'},
            {data: 'email', name: 'email'},
            {data: 'phone', name: 'phone'},
            {data: 'status', name: 'status'},
        ]
    });
});