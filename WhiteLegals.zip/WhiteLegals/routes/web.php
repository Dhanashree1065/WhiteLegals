<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ClientController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// login
Route::any('/login',[LoginController::class,'login']);
Route::post('admin/login',[LoginController::class,'submit_login']);
Route::get('/logout',[LoginController::class,'logout']);

// admin
Route::any('/admin/index',[AdminController::class,'index']);

// Employee
Route::any('employee/index',[EmployeeController::class,'index']);
Route::any('employee/create',[EmployeeController::class,'create']);
Route::any('employee/store',[EmployeeController::class,'store']);
Route::any('employee/{id}/edit',[EmployeeController::class,'edit']);
Route::any('employee/{id}/update',[EmployeeController::class,'update']);
Route::get('employee/{id}/delete',[EmployeeController::class,'destroy']);

// Client
Route::any('client/index',[ClientController::class,'index']);
Route::any('client/create',[ClientController::class,'create']);
Route::any('client/store',[ClientController::class,'store']);
Route::any('client/{id}/edit',[ClientController::class,'edit']);
Route::any('client/{id}/update',[ClientController::class,'update']);
Route::get('client/{id}/delete',[ClientController::class,'destroy']);

Route::any('logout',[LoginController::class,'logout']);