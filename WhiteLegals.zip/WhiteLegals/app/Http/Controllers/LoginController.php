<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;


class LoginController extends Controller
{
    public function login(Request $request){
        return view('login');
    }

    public function submit_login(Request $request){
        // dd($_POST);
        $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        $checkAdmin = Admin::where(['username'=>$request->username, 'password'=>$request->password])->count();
        // dd($checkAdmin);
        if($checkAdmin>0){
            session(['adminLogin',true]);
            return redirect('employee/index');
        }else{
            return redirect('login')->with('msg','Invalid username/password!!!');
        }
    }

    public function logout(){
        session()->forget('adminLogin');
        return redirect('login');
    }
}
