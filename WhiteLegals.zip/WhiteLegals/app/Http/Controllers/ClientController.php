<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\client_wl;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = client_wl::all();
        return view('client.index', ['data'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('client.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email'=> 'required',
            'address'=> 'required',
            'city'=> 'required',
            'notes' => 'required'
        ]);
        $data = new client_wl();
        // dd($data);
        $data->name = $request->name;
        $data->email = $request->email;
        $data->address = $request->address;
        $data->city = $request->city;
        $data->notes = $request->notes;
        $data->save();

        return redirect('client/index')->with('msg','Client data has been saved');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = client_wl::find($id);
        return view('client.edit',['data'=>$data]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            
            'name' => 'required',
            'email'=> 'required',
            'address'=> 'required',
            'city'=> 'required',
            'notes' => 'required'
        ]);
        
        $data = client_wl::find($id);
        
        $data->name = $request->name;
        $data->email = $request->email;
        $data->address = $request->address;
        $data->city = $request->city;
        $data->notes = $request->notes;
        $data->save();

        return redirect('client/index')->with('msg','Client data has been updated');
        // return view('employee.edit',['data'=>$data]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        client_wl::where('id',$id)->delete();
        return redirect('client/index');
    }
}
