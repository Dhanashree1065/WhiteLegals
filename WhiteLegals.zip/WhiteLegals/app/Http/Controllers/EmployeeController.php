<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\employee_wl;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = employee_wl::all();
        return view('employee.index', ['data'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employee.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($_POST);die;
        $request->validate([
            
            'name' => 'required',
            'email'=> 'required',
            'phone'=> 'required',
            'status'=> 'required'
        ]);
        $data = new employee_wl();
        // dd($data);
        
        $data->name = $request->name;
        $data->email = $request->email;
        $data->phone = $request->phone;
        $data->status = $request->status;
        $data->save();

        return redirect('employee/index')->with('msg','Employee data has been saved');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = employee_wl::find($id);
        return view('employee.edit',['data'=>$data]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'email'=> 'required',
            'phone'=> 'required',
            'status'=> 'required'
        ]);
        $data = employee_wl::find($id);
        // dd($data);
        
        $data->name = $request->name;
        $data->email = $request->email;
        $data->phone = $request->phone;
        $data->status = $request->status;
        $data->save();

        return redirect('employee/index')->with('msg','Employee data has been updated');
        // return view('employee.edit',['data'=>$data]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        employee_wl::where('id',$id)->delete();
        return redirect('employee/index');
    }
}
