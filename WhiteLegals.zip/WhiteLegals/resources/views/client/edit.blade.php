@extends('layout.layout')
@section('title','Update Client')
@section('content')
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Update Client
        <a href="{{ url('client/index') }}" class="btn btn-dark float-end">View Clients</a>
    </div>
    <div class="card-body">
        
        <form method="post" action="{{ url('client/'.$data->id.'/update') }}" enctype="multipart/form-data">
            @csrf
            <table class="table table-bordered">
           
                <tr>
                    <th>Name</th>
                    <td><input type="text" class="form-control" name="name" value="{{$data->name}}"/></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><input type="email" class="form-control" name="email" value="{{$data->email}}"></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><input type="text" class="form-control" name="address" value="{{$data->address}}"></td>
                </tr>

                <tr>
                    <th>City</th>
                    <td><input type="text" class="form-control" name="city" value="{{$data->city}}"></td>
                </tr>

                <tr>
                    <th>Notes</th>
                    <td><textarea class="form-control" name="notes" rows="4" class="50">{{$data->notes}}</textarea></td>
                    
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update" class="btn btn-primary float-end"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>


@endsection