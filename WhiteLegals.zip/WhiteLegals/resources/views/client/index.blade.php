@extends('layout.layout')
@section('title','Client List')
@section('content')
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Client List
        <a href="{{ url('client/create') }}" class="btn btn-primary float-end">Add Client</a>
    </div>
    <div class="card-body">
        @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="text-danger">{{ $error }}</p>
        @endforeach
        @endif

        @if(Session::has('msg'))
        <p class="text-success">{{ session('msg') }}</p>
        @endif
        <table class="table table-bordered" id="datatablesSimple">
            <thead>
                <tr>
                    
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                @if($data)
                @foreach($data as $d)
                <tr>
                    
                    <td>{{$d->name}}</td>
                    <td>{{$d->email}}</td>
                    <td>{{$d->address}}</td>
                    <td>{{$d->city}}</td>
                    <td>{{$d->notes}}</td>
                    <td>
                        <a href="{{ url('client/'.$d->id.'/edit') }}"><i class="fa-solid fa-pen-to-square text-success"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="{{ url('client/'.$d->id.'/delete') }}" onclick="return confirm('Are you sure to delete this client data?')"><i class="fa-solid fa-trash text-danger"></i></a>
                    </td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>
    </div>
</div>
@endsection