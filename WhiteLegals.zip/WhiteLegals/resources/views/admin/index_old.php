<!-- @extends('layout.app')
@section('content') -->
<!doctype html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta name="base_url" content="{{  url('/') }}">
	<title>Admin</title>
	<!-- <link rel="icon" href="dist/images/mdb-favicon.ico" type="image/x-icon"> -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
	<link rel="stylesheet" href="{{ asset('admin-assets/css/font-awesome.css') }}">

	<link href="{{ asset('admin-assets/css/jquery.dataTables.min.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-assets/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
	
</head>


<body class="normal-admin">
	
	<main class="normal_admin_panel active">

		<!--DASHBOARD TAB start-->
		<section class="section dashboard_sec" id="dashboard">


<div class="container">
    <table class="table table-bordered data-table">
        <thead>
            <tr>Sr. No.</tr>
            <tr>Name</tr>
            <tr>Email</tr>
            <tr>Phone Number</tr>
            <tr>Status</tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<!-- @endsection -->
</section>
		</main>
	</body> 
    <script src="{{ asset('admin-assets/js/jquery.dataTables.min.js') }}"></script>
	<script src="{{ asset('admin-assets/js/dataTables.bootstrap4.min.js') }}"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>

    <script src="{{ asset('admin-assets/js/admin-datatable.js') }}"></script>
</html>


   

