@extends('layout.layout')
@section('content')
Dashboard
@endsection