@extends('layout.layout')
@section('title','Employee List')
@section('content')
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Employee List
        <a href="{{ url('employee/create') }}" class="btn btn-primary float-end">Add Employee</a>
    </div>
    <div class="card-body">
        @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="text-danger">{{ $error }}</p>
        @endforeach
        @endif

        @if(Session::has('msg'))
        <p class="text-success">{{ session('msg') }}</p>
        @endif

        <table class="table table-bordered" id="datatablesSimple">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
            <tbody>
                @if($data)
                @foreach($data as $d)
                <tr>
                    
                    <td>{{$d->name}}</td>
                    <td>{{$d->email}}</td>
                    <td>{{$d->phone}}</td>
                    <td>{{ $d->status == 1 ? 'Active' : 'Inactive' }}</td>

                    
                    <td>
                        <a href="{{ url('employee/'.$d->id.'/edit') }}"><i class="fa-solid fa-pen-to-square text-success"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="{{ url('employee/'.$d->id.'/delete') }}" onclick="return confirm('Are you sure to delete this employee data?')"><i class="fa-solid fa-trash text-danger"></i></a>
                    </td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>
    </div>
</div>


@endsection