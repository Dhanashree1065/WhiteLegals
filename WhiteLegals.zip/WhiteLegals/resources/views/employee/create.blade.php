@extends('layout.layout')
@section('title','Add Employee')
@section('content')
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Add Employee
        <a href="{{ url('employee/index') }}" class="btn btn-dark float-end">View Employees</a>
    </div>
    <div class="card-body">
        
        <form method="post" action="{{ url('employee/store') }}">
            @csrf
            <table class="table table-bordered">

                <tr>
                    <th>Name</th>
                    <td><input type="text" class="form-control" name="name" /></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><input type="email" class="form-control" name="email"></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><input type="number" class="form-control" name="phone"></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>

                        <input type="radio" checked="true" name="status" value="1" />&nbsp;&nbsp;&nbsp;Active<br>
                        <input type="radio" name="status" value="0" />&nbsp;&nbsp;&nbsp;Inactive

                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Submit" class="btn btn-primary float-end" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>


@endsection