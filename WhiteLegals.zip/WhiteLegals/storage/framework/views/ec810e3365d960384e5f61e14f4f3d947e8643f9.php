<?php $__env->startSection('title','Update Employee'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Update Employee
        <a href="<?php echo e(url('employee/index')); ?>" class="btn btn-dark float-end">View Employees</a>
    </div>
    <div class="card-body">
        
        <form method="post" action="<?php echo e(url('employee/'.$data->id.'/update')); ?>">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <table class="table table-bordered">

                <tr>
                    <th>Name</th>
                    <td><input type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>" /></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>"></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><input type="number" class="form-control" name="phone" value="<?php echo e($data->phone); ?>"></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>

                        <input type="radio" name="status" value="1" <?php if($data->status === '1'): ?> checked <?php endif; ?>/>&nbsp;&nbsp;&nbsp;Activate<br>
                        <input type="radio" name="status" value="0" <?php if($data->status === '0'): ?> checked <?php endif; ?> />&nbsp;&nbsp;&nbsp;Deactivate
        
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update" class="btn btn-primary float-end" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Dhanashree/Laravel_Project/WhiteLegals/resources/views/employee/edit.blade.php ENDPATH**/ ?>