<?php $__env->startSection('title','Employee List'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Employee List
        <a href="<?php echo e(url('employee/create')); ?>" class="btn btn-primary float-end">Add Employee</a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="text-danger"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(Session::has('msg')): ?>
        <p class="text-success"><?php echo e(session('msg')); ?></p>
        <?php endif; ?>

        <table class="table table-bordered" id="datatablesSimple">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
            <tbody>
                <?php if($data): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($d->name); ?></td>
                    <td><?php echo e($d->email); ?></td>
                    <td><?php echo e($d->phone); ?></td>
                    <td><?php echo e($d->status == 1 ? 'Active' : 'Inactive'); ?></td>

                    
                    <td>
                        <a href="<?php echo e(url('employee/'.$d->id.'/edit')); ?>"><i class="fa-solid fa-pen-to-square text-success"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="<?php echo e(url('employee/'.$d->id.'/delete')); ?>" onclick="return confirm('Are you sure to delete this employee data?')"><i class="fa-solid fa-trash text-danger"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Dhanashree/Laravel_Project/WhiteLegals/resources/views/employee/index.blade.php ENDPATH**/ ?>