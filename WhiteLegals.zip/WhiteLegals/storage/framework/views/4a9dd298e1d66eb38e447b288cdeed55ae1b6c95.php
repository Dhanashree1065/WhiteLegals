<?php $__env->startSection('title','Client List'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-5">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Client List
        <a href="<?php echo e(url('client/create')); ?>" class="btn btn-primary float-end">Add Client</a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="text-danger"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(Session::has('msg')): ?>
        <p class="text-success"><?php echo e(session('msg')); ?></p>
        <?php endif; ?>
        <table class="table table-bordered" id="datatablesSimple">
            <thead>
                <tr>
                    
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php if($data): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($d->name); ?></td>
                    <td><?php echo e($d->email); ?></td>
                    <td><?php echo e($d->address); ?></td>
                    <td><?php echo e($d->city); ?></td>
                    <td><?php echo e($d->notes); ?></td>
                    <td>
                        <a href="<?php echo e(url('client/'.$d->id.'/edit')); ?>"><i class="fa-solid fa-pen-to-square text-success"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="<?php echo e(url('client/'.$d->id.'/delete')); ?>" onclick="return confirm('Are you sure to delete this client data?')"><i class="fa-solid fa-trash text-danger"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Dhanashree/Laravel_Project/WhiteLegals/resources/views/client/index.blade.php ENDPATH**/ ?>